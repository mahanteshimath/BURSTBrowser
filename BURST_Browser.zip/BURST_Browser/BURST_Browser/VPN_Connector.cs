﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BURST_Browser
{
    public partial class VPN_Connector : Form
    {
        public VPN_Connector()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("rasdial.exe", "My_VPN My_Username My_Password");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("rasdial.exe", "My_VPN /d");
        }
    }
}
