﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BURST_Browser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (About about = new About())
            {
                about.ShowDialog();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            (tabControl1.SelectedTab.Controls[0] as WebBrowser).Navigate(txtURL.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            newTabToolStripMenuItem_Click(this, EventArgs.Empty);
        }

        private void newTabToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TabPage tabPage = new TabPage();
            WebBrowser webBrowser = new WebBrowser();
            webBrowser.Parent = tabPage;
            webBrowser.Dock = DockStyle.Fill;
            webBrowser.Navigate("https://www.burst-team.us/");
            webBrowser.Navigated += WebBrowser_Navigated;

            tabControl1.TabPages.Add(tabPage);
            tabControl1.SelectTab(tabPage);
        }

        private void WebBrowser_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            (sender as WebBrowser).Parent.Text = (sender as WebBrowser).DocumentTitle;
            if ((sender as WebBrowser).Parent.Visible)
            {
                txtURL.Text = (sender as WebBrowser).Url.AbsoluteUri;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            (tabControl1.SelectedTab.Controls[0] as WebBrowser).GoBack();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            (tabControl1.SelectedTab.Controls[0] as WebBrowser).GoForward();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            (tabControl1.SelectedTab.Controls[0] as WebBrowser).Refresh();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            (tabControl1.SelectedTab.Controls[0] as WebBrowser).Stop();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void toolStripProgressBar1_Click(object sender, EventArgs e)
        {
            
        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            txtURL.Text = (e.TabPage.Controls[0] as WebBrowser).Url.AbsoluteUri;
        }

        private void vPNConnectorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VPN_Connector vpnconnector = new VPN_Connector();
            vpnconnector.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();
            settings.Show();
        }
    }
}
