﻿namespace BURST_Browser_V3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.logo = new System.Windows.Forms.PictureBox();
            this.backBtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.fwdBtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.goBtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.txtUrl = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.addTabBtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.rmTabBtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.settingsBtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fwdBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addTabBtn)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rmTabBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.settingsBtn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.panel1.Controls.Add(this.settingsBtn);
            this.panel1.Controls.Add(this.rmTabBtn);
            this.panel1.Controls.Add(this.addTabBtn);
            this.panel1.Controls.Add(this.txtUrl);
            this.panel1.Controls.Add(this.goBtn);
            this.panel1.Controls.Add(this.fwdBtn);
            this.panel1.Controls.Add(this.backBtn);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1264, 30);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85)))));
            this.panel2.Controls.Add(this.logo);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(33, 56);
            this.panel2.TabIndex = 2;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // logo
            // 
            this.logo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logo.BackgroundImage")));
            this.logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.logo.Location = new System.Drawing.Point(4, 3);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(25, 25);
            this.logo.TabIndex = 2;
            this.logo.TabStop = false;
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Transparent;
            this.backBtn.Image = ((System.Drawing.Image)(resources.GetObject("backBtn.Image")));
            this.backBtn.ImageActive = null;
            this.backBtn.Location = new System.Drawing.Point(36, 2);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(25, 25);
            this.backBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.backBtn.TabIndex = 2;
            this.backBtn.TabStop = false;
            this.backBtn.Zoom = 10;
            this.backBtn.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // fwdBtn
            // 
            this.fwdBtn.BackColor = System.Drawing.Color.Transparent;
            this.fwdBtn.Image = ((System.Drawing.Image)(resources.GetObject("fwdBtn.Image")));
            this.fwdBtn.ImageActive = null;
            this.fwdBtn.Location = new System.Drawing.Point(63, 2);
            this.fwdBtn.Name = "fwdBtn";
            this.fwdBtn.Size = new System.Drawing.Size(25, 25);
            this.fwdBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.fwdBtn.TabIndex = 3;
            this.fwdBtn.TabStop = false;
            this.fwdBtn.Zoom = 10;
            this.fwdBtn.Click += new System.EventHandler(this.fwdBtn_Click);
            // 
            // goBtn
            // 
            this.goBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.goBtn.BackColor = System.Drawing.Color.Transparent;
            this.goBtn.Image = ((System.Drawing.Image)(resources.GetObject("goBtn.Image")));
            this.goBtn.ImageActive = null;
            this.goBtn.Location = new System.Drawing.Point(1144, 3);
            this.goBtn.Name = "goBtn";
            this.goBtn.Size = new System.Drawing.Size(25, 25);
            this.goBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.goBtn.TabIndex = 4;
            this.goBtn.TabStop = false;
            this.goBtn.Zoom = 10;
            this.goBtn.Click += new System.EventHandler(this.goBtn_Click);
            // 
            // txtUrl
            // 
            this.txtUrl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUrl.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtUrl.Location = new System.Drawing.Point(94, 5);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(1044, 20);
            this.txtUrl.TabIndex = 5;
            this.txtUrl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUrl_KeyPress);
            // 
            // addTabBtn
            // 
            this.addTabBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.addTabBtn.BackColor = System.Drawing.Color.Transparent;
            this.addTabBtn.Image = ((System.Drawing.Image)(resources.GetObject("addTabBtn.Image")));
            this.addTabBtn.ImageActive = null;
            this.addTabBtn.Location = new System.Drawing.Point(1171, 3);
            this.addTabBtn.Name = "addTabBtn";
            this.addTabBtn.Size = new System.Drawing.Size(25, 25);
            this.addTabBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.addTabBtn.TabIndex = 6;
            this.addTabBtn.TabStop = false;
            this.addTabBtn.Zoom = 10;
            this.addTabBtn.Click += new System.EventHandler(this.addTabBtn_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.webBrowser1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1256, 624);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(0, 31);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1264, 650);
            this.tabControl1.TabIndex = 2;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(3, 3);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.ScriptErrorsSuppressed = true;
            this.webBrowser1.Size = new System.Drawing.Size(1250, 618);
            this.webBrowser1.TabIndex = 0;
            // 
            // rmTabBtn
            // 
            this.rmTabBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.rmTabBtn.BackColor = System.Drawing.Color.Transparent;
            this.rmTabBtn.Image = ((System.Drawing.Image)(resources.GetObject("rmTabBtn.Image")));
            this.rmTabBtn.ImageActive = null;
            this.rmTabBtn.Location = new System.Drawing.Point(1199, 3);
            this.rmTabBtn.Name = "rmTabBtn";
            this.rmTabBtn.Size = new System.Drawing.Size(25, 25);
            this.rmTabBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.rmTabBtn.TabIndex = 7;
            this.rmTabBtn.TabStop = false;
            this.rmTabBtn.Zoom = 10;
            this.rmTabBtn.Click += new System.EventHandler(this.bunifuImageButton1_Click_1);
            // 
            // settingsBtn
            // 
            this.settingsBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.settingsBtn.BackColor = System.Drawing.Color.Transparent;
            this.settingsBtn.Image = ((System.Drawing.Image)(resources.GetObject("settingsBtn.Image")));
            this.settingsBtn.ImageActive = null;
            this.settingsBtn.Location = new System.Drawing.Point(1227, 3);
            this.settingsBtn.Name = "settingsBtn";
            this.settingsBtn.Size = new System.Drawing.Size(25, 25);
            this.settingsBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.settingsBtn.TabIndex = 8;
            this.settingsBtn.TabStop = false;
            this.settingsBtn.Zoom = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BURST Browser";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fwdBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addTabBtn)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rmTabBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.settingsBtn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox logo;
        private Bunifu.Framework.UI.BunifuImageButton backBtn;
        private Bunifu.Framework.UI.BunifuImageButton fwdBtn;
        private Bunifu.Framework.UI.BunifuImageButton goBtn;
        private WindowsFormsControlLibrary1.BunifuCustomTextbox txtUrl;
        private Bunifu.Framework.UI.BunifuImageButton addTabBtn;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.TabControl tabControl1;
        private Bunifu.Framework.UI.BunifuImageButton rmTabBtn;
        private Bunifu.Framework.UI.BunifuImageButton settingsBtn;
    }
}

